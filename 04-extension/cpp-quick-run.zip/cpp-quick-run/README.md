# Cpp Quick Run

One-click compile & run for C++ on Windows, targeting the **MSYS2 UCRT64** toolchain.
No external console windows — compilation runs hidden, and the program runs
inside VS Code's integrated terminal so `std::cin` works normally.

## Try it (no build step, zero dependencies)

1. Open this folder in VS Code.
2. Press `F5`. This launches an **Extension Development Host** window with
   the extension active.
3. In that window, open (or create) a `.cpp` file and click the ▶ **Run C++**
   button in the editor title bar (or press `Ctrl+Alt+N`).

## Requirements

- MSYS2 installed at `C:\msys64` with the UCRT64 toolchain:
  ```
  pacman -S mingw-w64-ucrt-x86_64-gcc
  ```
- For SFML mode:
  ```
  pacman -S mingw-w64-ucrt-x86_64-sfml
  ```

## What happens when you click Run

1. The active `.cpp` file is saved.
2. Project type (normal vs. SFML) is resolved — see below.
3. `g++.exe` compiles to `<buildDirectory>/<filename>.exe`.
4. **On failure**: errors appear in the **"Cpp Quick Run"** Output panel.
5. **On success**: the executable runs in a dedicated integrated terminal,
   with the compiler's `bin` folder added to `PATH` for that session so
   runtime DLLs (`libstdc++-6.dll`, SFML DLLs, etc.) resolve automatically.

## Settings

| Setting | Default | Description |
|---|---|---|
| `cppQuickRun.compilerPath` | `C:\msys64\ucrt64\bin\g++.exe` | Path to g++. |
| `cppQuickRun.enableSFML` | `false` | Adds SFML flags via `pkg-config`. |
| `cppQuickRun.compilerArgs` | `["-std=c++17", "-Wall"]` | Extra g++ arguments. |
| `cppQuickRun.buildDirectory` | `build` | Output dir (relative to workspace root, or absolute). |

## Per-project auto-detection (optional)

Instead of toggling `cppQuickRun.enableSFML` per workspace, drop a
`.cppquickrun.json` file in the workspace root:

```json
{
  "type": "sfml",
  "compiler": "C:\\msys64\\ucrt64\\bin\\g++.exe",
  "libs": ["sfml-graphics", "sfml-audio"]
}
```

- `type`: `"normal"` or `"sfml"` — overrides `cppQuickRun.enableSFML`.
- `compiler`: optional override of `cppQuickRun.compilerPath` for this project.
- `libs`: pkg-config module names (defaults to `["sfml-graphics"]`).

The extension checks for this file every run, so opening a different project
automatically switches modes — no manual toggling.

## Packaging as a .vsix (optional)

```
npm install -g @vscode/vsce
vsce package
```

## Not in v1 (by design — kept minimal)

- Multi-file / CMake projects (single translation unit only).
- Non-Windows platforms.
- Paths containing spaces in `pkg-config` output (fine for default MSYS2 installs).
