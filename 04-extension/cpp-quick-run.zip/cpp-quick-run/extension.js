// Cpp Quick Run
// Compiles the active .cpp file with MSYS2 UCRT64 g++ and runs it in the
// integrated terminal. Optional SFML mode resolves flags via pkg-config.

const vscode = require('vscode');
const path = require('path');
const fs = require('fs');
const cp = require('child_process');

let outputChannel;
let runTerminal;

function activate(context) {
  outputChannel = vscode.window.createOutputChannel('Cpp Quick Run');
  context.subscriptions.push(outputChannel);

  const disposable = vscode.commands.registerCommand('cppQuickRun.run', runCpp);
  context.subscriptions.push(disposable);

  context.subscriptions.push(
    vscode.window.onDidCloseTerminal((t) => {
      if (t === runTerminal) runTerminal = undefined;
    })
  );
}

function deactivate() {}

async function runCpp() {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showErrorMessage('Cpp Quick Run: No active editor.');
    return;
  }

  const doc = editor.document;
  if (path.extname(doc.fileName).toLowerCase() !== '.cpp') {
    vscode.window.showErrorMessage('Cpp Quick Run: The active file is not a .cpp file.');
    return;
  }

  await doc.save();

  const config = vscode.workspace.getConfiguration('cppQuickRun', doc.uri);
  const workspaceFolder = vscode.workspace.getWorkspaceFolder(doc.uri);
  const projectConfig = loadProjectConfig(workspaceFolder);

  const compilerPath =
    projectConfig.compiler || config.get('compilerPath') || 'C:\\msys64\\ucrt64\\bin\\g++.exe';
  const enableSFML = projectConfig.type ? projectConfig.type === 'sfml' : config.get('enableSFML', false);
  const extraArgs = config.get('compilerArgs', []);
  const buildDirSetting = config.get('buildDirectory', 'build');

  if (!fs.existsSync(compilerPath)) {
    vscode.window.showErrorMessage(
      `Cpp Quick Run: Compiler not found at "${compilerPath}". Check the cppQuickRun.compilerPath setting.`
    );
    return;
  }

  const compilerDir = path.dirname(compilerPath);
  const sourceFile = doc.fileName;
  const sourceDir = path.dirname(sourceFile);
  const baseName = path.basename(sourceFile, '.cpp');

  const resolvedBuildDir = path.isAbsolute(buildDirSetting)
    ? buildDirSetting
    : path.join(workspaceFolder ? workspaceFolder.uri.fsPath : sourceDir, buildDirSetting);

  try {
    fs.mkdirSync(resolvedBuildDir, { recursive: true });
  } catch (err) {
    vscode.window.showErrorMessage(`Cpp Quick Run: Could not create build directory: ${err.message}`);
    return;
  }

  const exePath = path.join(resolvedBuildDir, `${baseName}.exe`);

  let sfmlFlags = [];
  if (enableSFML) {
    try {
      const libs = projectConfig.libs || ['sfml-graphics'];
      sfmlFlags = await getPkgConfigFlags(compilerDir, libs);
    } catch (err) {
      outputChannel.clear();
      outputChannel.appendLine('[Cpp Quick Run] Failed to resolve SFML flags via pkg-config:');
      outputChannel.appendLine(err.message);
      outputChannel.show(true);
      vscode.window.showErrorMessage(
        'Cpp Quick Run: pkg-config failed. Is SFML installed in MSYS2 UCRT64 ' +
          '(pacman -S mingw-w64-ucrt-x86_64-sfml)?'
      );
      return;
    }
  }

  const gppArgs = [sourceFile, '-o', exePath, ...extraArgs, ...sfmlFlags];

  vscode.window.setStatusBarMessage(
    `Cpp Quick Run: Compiling${enableSFML ? ' (SFML)' : ''}...`,
    3000
  );

  try {
    await compile(compilerPath, gppArgs, compilerDir, sourceDir);
  } catch (err) {
    outputChannel.clear();
    outputChannel.appendLine(`[Cpp Quick Run] Compilation failed: ${sourceFile}`);
    outputChannel.appendLine('');
    outputChannel.appendLine(err.message);
    outputChannel.show(true);
    vscode.window.showErrorMessage('Cpp Quick Run: Compilation failed. See "Cpp Quick Run" output.');
    return;
  }

  runInTerminal(exePath, compilerDir);
}

// Looks for a per-project override file in the workspace root, e.g.:
// { "type": "sfml", "compiler": "C:\\msys64\\ucrt64\\bin\\g++.exe", "libs": ["sfml-graphics", "sfml-audio"] }
function loadProjectConfig(workspaceFolder) {
  if (!workspaceFolder) return {};

  const configPath = path.join(workspaceFolder.uri.fsPath, '.cppquickrun.json');
  if (!fs.existsSync(configPath)) return {};

  try {
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
  } catch (err) {
    vscode.window.showWarningMessage(`Cpp Quick Run: Failed to parse .cppquickrun.json: ${err.message}`);
    return {};
  }
}

function getPkgConfigFlags(compilerDir, libs) {
  return new Promise((resolve, reject) => {
    const pkgConfigPath = path.join(compilerDir, 'pkg-config.exe');
    if (!fs.existsSync(pkgConfigPath)) {
      reject(new Error(`pkg-config.exe not found at ${pkgConfigPath}`));
      return;
    }

    cp.execFile(
      pkgConfigPath,
      ['--cflags', '--libs', ...libs],
      { windowsHide: true },
      (err, stdout, stderr) => {
        if (err) {
          reject(new Error(stderr || err.message));
          return;
        }
        const flags = stdout.trim().split(/\s+/).filter(Boolean);
        resolve(flags);
      }
    );
  });
}

function compile(compilerPath, args, compilerDir, cwd) {
  return new Promise((resolve, reject) => {
    const env = Object.assign({}, process.env, {
      PATH: `${compilerDir};${process.env.PATH || ''}`
    });

    cp.execFile(
      compilerPath,
      args,
      { windowsHide: true, env, cwd, maxBuffer: 10 * 1024 * 1024 },
      (err, stdout, stderr) => {
        if (err) {
          reject(new Error(stderr || stdout || err.message));
          return;
        }
        if (stderr) {
          // g++ prints warnings to stderr even on success
          outputChannel.appendLine(stderr);
        }
        resolve();
      }
    );
  });
}

function runInTerminal(exePath, compilerDir) {
  if (!runTerminal) {
    runTerminal = vscode.window.createTerminal({
      name: 'Cpp Quick Run',
      env: { PATH: `${compilerDir};${process.env.PATH || ''}` }
    });
  }
  runTerminal.show();
  runTerminal.sendText(buildRunCommand(exePath));
}

function buildRunCommand(exePath) {
  const shell = (vscode.env.shell || '').toLowerCase();
  const isPowerShell = shell.includes('powershell') || shell.includes('pwsh');
  const quoted = `"${exePath}"`;
  return isPowerShell ? `& ${quoted}` : quoted;
}

module.exports = { activate, deactivate };
